let user = new Vue({
    el: '#user',
    data: {
        is_logged_in: false,
        name: "Name Name Name Name Name Name"
    }
});